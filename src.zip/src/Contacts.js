import React from 'react'

    const Contacts = ({ contacts }) => {
      return (
            

        <div>
        <div>
          <center><h1>Contact List</h1></center>
          {contacts.map((contact) => (
              <div className="content-wrapper">
              <div className="card-body">
                <div className="form-group">
                  <label htmlFor="exampleInputEmail1">Email address</label>
                  <input type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter email" value={contact.name}/>
                </div>
                <div className="form-group">
                  <label htmlFor="exampleInputPassword1">Password</label>
                  <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" />
                </div>
                <div className="form-group">
                  <label htmlFor="exampleInputFile">File input</label>
                  <div className="input-group">
                    <div className="custom-file">
                      <input type="file" className="custom-file-input" id="exampleInputFile" />
                      <label className="custom-file-label" htmlFor="exampleInputFile">Choose file</label>
                    </div>
                    <div className="input-group-append">
                      <span className="input-group-text" id>Upload</span>
                    </div>
                  </div>
                </div>
                <div className="form-check">
                  <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                  <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
                </div>
              </div>
              {/* /.card-body */}


  
  
  <div>

  </div>

          </div>


            
            
                  ))}
        </div>
        </div>
      )
    };

    export default Contacts