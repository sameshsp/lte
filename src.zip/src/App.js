import React, { Component } from 'react'
import Header from './Header'
import Menu from './Menu'
import Footer from './Footer'
//import Content from './Content'
//import Form from './Form'
//import FormContainer from './FormContainer'
import User from './User'
import SimpleForm from './Masters/SimpleForm'


export default class App extends Component {
    render() {
        return (
            <div>
                <Header/>
                <Menu/>
                <User />
                <SimpleForm />
                <Footer/>
            </div>
        )
    }
}
